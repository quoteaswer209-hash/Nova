# NOVA CHAT — مشروع البداية

نسخة تأسيسية قابلة للتشغيل والتطوير لتطبيق مراسلة بواجهة عربية متجاوبة، React + TypeScript + Vite، مع Supabase للمصادقة وقاعدة البيانات وDexie/IndexedDB للتخزين المحلي.

> **مهم:** هذا المشروع ليس نسخة مكتملة تنافس WhatsApp أو Signal حتى الآن. الواجهة الأساسية وتسجيل البريد الإلكتروني والتخزين المحلي وطابور الرسائل موجودة. المكالمات وE2E Encryption والقنوات والقصص والإشعارات وNearby Messaging وAI ورفع المرفقات لم تُنفذ بعد، لذلك لا تظهر كميزات عاملة.

## المتطلبات
- Node.js 20.19+ أو 22.12+
- npm
- حساب Supabase (اختياري لتجربة الواجهة محليًا، مطلوب للمصادقة والمزامنة السحابية)

## التشغيل
1. فك ضغط `NOVA_CHAT.zip`.
2. افتح مجلد `NOVA_CHAT` في Terminal.
3. نفّذ:
   ```bash
   npm install
   ```
4. شغّل الواجهة:
   ```bash
   npm run dev
   ```
5. افتح العنوان الذي يظهر في Terminal.

## إعداد Supabase
1. أنشئ مشروعًا جديدًا في Supabase.
2. افتح SQL Editor ونفّذ محتوى `supabase/schema.sql`.
3. من Project Settings ثم API انسخ Project URL و anon/public key.
4. انسخ `.env.example` إلى ملف باسم `.env` في جذر المشروع.
5. املأ القيم:
   ```env
   VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
   ```
6. فعّل Email Auth من Authentication > Providers، واضبط تأكيد البريد وفق إعداداتك.
7. أعد تشغيل `npm run dev`.

لا تضع `service_role` key في الواجهة أو ملف `.env` الخاص بالعميل. استخدم anon key فقط مع سياسات RLS.

## ما يعمل في هذه النسخة
- واجهة NOVA CHAT عربية RTL ومتجاوبة.
- وضع داكن/فاتح.
- بحث محلي في قائمة المحادثات التجريبية.
- إدخال الرسائل وحفظها في IndexedDB على الجهاز.
- الاحتفاظ بالرسائل المعلقة بعد إغلاق الصفحة.
- محاولة مزامنة الرسائل المعلقة عند عودة الإنترنت، بشرط إعداد Supabase ووجود جلسة صحيحة ومحادثة فعلية وعضوية المستخدم فيها.
- إنشاء حساب/تسجيل دخول بالبريد عبر Supabase بعد الإعداد.

## حدود النسخة الحالية
- المحادثات الظاهرة في القائمة بيانات واجهة محلية وليست محادثات حقيقية في قاعدة البيانات.
- لا توجد بعد شاشة لإنشاء المحادثات أو إضافة الأعضاء؛ لذلك يلزم إنشاء المحادثة وعضويتها من خلال Backend موثوق قبل إرسال رسائل سحابية.
- الرسائل المحلية في المحادثات التجريبية لا تُرفع للسحابة.
- لا يوجد E2EE؛ لا تستخدم التطبيق لتبادل بيانات حساسة.
- لا يوجد رفع ملفات فعلي أو Push Notifications أو WebRTC أو Nearby/Bluetooth.
- لا توجد مصادقة OTP للهاتف أو Google/Apple في هذه المرحلة.

## أوامر مفيدة
```bash
npm run dev       # تشغيل التطوير
npm run typecheck # فحص TypeScript
npm run build     # بناء نسخة الإنتاج
npm run preview   # معاينة نسخة الإنتاج
```

## هيكل المشروع
```text
NOVA_CHAT/
├── src/
│   ├── lib/          # Supabase وIndexedDB والمزامنة
│   ├── types/
│   ├── App.tsx
│   ├── main.tsx
│   └── styles.css
├── supabase/
│   └── schema.sql
├── .env.example
├── package.json
└── README.md
```

## خارطة الطريق المقترحة
1. بناء APIs/Edge Functions لإنشاء المحادثات وإدارة العضويات والتحقق من الصلاحيات.
2. ربط قائمة المحادثات والرسائل ببيانات قاعدة البيانات وSupabase Realtime.
3. إضافة إيصالات التسليم والقراءة، التعديل والحذف والتفاعلات.
4. إضافة Storage آمن للمرفقات مع سياسات وصول.
5. اختبار مزامنة offline وحل تعارضات التعديل وترتيب الرسائل.
6. تطبيق بروتوكول E2EE موثوق ومدقق قبل وصف المحادثات بأنها مشفرة طرفيًا.
7. إضافة WebRTC مع STUN/TURN وإشعارات المكالمات.
8. بناء تطبيق هاتف مستقل عند الحاجة إلى Bluetooth/Wi-Fi Direct والإشعارات الخلفية.


## تحويل المشروع إلى Android APK باستخدام Capacitor

المشروع واجهة ويب React، وتمت إضافة إعداد Capacitor لتغليفها كتطبيق Android. يلزم كمبيوتر Windows/macOS/Linux، وليس الهاتف وحده، لإكمال بناء APK بالطريقة المعتادة.

### المتطلبات
- Node.js 20.19+ أو 22.12+
- Android Studio بإصدار حديث
- Android SDK مثبت من Android Studio
- Java/JDK المتوافق مع إصدار Android Gradle Plugin الذي يجهزه Android Studio

### إنشاء مشروع Android لأول مرة
من داخل مجلد `NOVA_CHAT` شغّل:

```bash
npm install
npm run android:add
```

إذا كنت تستخدم Supabase، أنشئ ملف `.env` واضبط متغيراته قبل البناء، كما هو موضح في قسم إعداد Supabase أعلاه.

### بناء ومزامنة ملفات التطبيق
```bash
npm run android:sync
npm run android:open
```

سيفتح Android Studio مشروع Android. انتظر انتهاء Gradle Sync.

### إخراج APK تجريبي
من Android Studio:
1. اختر Build من القائمة.
2. اختر Build Bundle(s) / APK(s).
3. اختر Build APK(s).
4. بعد اكتمال البناء سيعرض Android Studio رابط مجلد APK الناتج.

ويمكن إنشاء APK Debug من الطرفية بعد إضافة منصة Android:
```bash
cd android
./gradlew assembleDebug
```
على Windows استخدم:
```powershell
.\gradlew.bat assembleDebug
```
الناتج غالبًا داخل:
`android/app/build/outputs/apk/debug/app-debug.apk`

### ملاحظات مهمة
- ملف مجلد `android/` لا يُضمّن هنا؛ يتم إنشاؤه محليًا بواسطة `npx cap add android` بعد تثبيت الحزم.
- هذا يغلف نسخة الويب الحالية فقط. لا يضيف تلقائيًا المكالمات أو Bluetooth/Wi-Fi Direct أو الإشعارات أو التشفير الطرفي.
- تسجيل الدخول والمزامنة السحابية يحتاجان إعداد Supabase وسياسات قاعدة البيانات الصحيحة.
- لا تنشر نسخة إنتاج قبل اختبار تسجيل الدخول، الصلاحيات، التخزين، وسياسات الخصوصية على جهاز فعلي.


## بناء APK تلقائيًا باستخدام GitHub Actions

أضف المشروع إلى مستودع GitHub:
1. أنشئ Repository جديدًا على GitHub.
2. ارفع كل محتويات مجلد `NOVA_CHAT` إلى الفرع `main` (بما في ذلك مجلد `.github`).
3. افتح تبويب **Actions** في المستودع.
4. اختر workflow باسم **Build NOVA CHAT APK**.
5. اضغط **Run workflow**، أو ادفع Commit إلى `main` ليبدأ البناء تلقائيًا.
6. بعد انتهاء التشغيل بنجاح، افتح صفحة التشغيل (workflow run) وانزل إلى **Artifacts**.
7. حمّل `NOVA-CHAT-debug-apk.zip`، ثم فك ضغطه وستجد `app-debug.apk`.

لا تحتاج إلى تثبيت Android Studio على جهازك لبناء APK عبر GitHub Actions.
لا ترفع ملف `.env` أو أي مفاتيح سرية إلى المستودع. أضف إعدادات الخدمات لاحقًا باستخدام GitHub Secrets عند الحاجة، مع الانتباه إلى أن متغيرات `VITE_` تُضمّن في تطبيق العميل ولا تصلح للأسرار الخاصة.
