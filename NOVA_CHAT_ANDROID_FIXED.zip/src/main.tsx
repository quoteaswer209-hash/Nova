import React, { Component, type ErrorInfo, type ReactNode } from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles.css";

class AppErrorBoundary extends Component<
  { children: ReactNode },
  { error: Error | null }
> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("NOVA CHAT render error:", error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <main dir="rtl" style={{
          minHeight: "100dvh", padding: 24, display: "grid",
          placeItems: "center", background: "#0b1020", color: "#f4f6ff",
          fontFamily: "Arial, sans-serif"
        }}>
          <section style={{
            width: "min(100%, 520px)", padding: 22, borderRadius: 18,
            background: "#18213b", border: "1px solid #ff737355"
          }}>
            <h2 style={{ color: "#ff9ca5" }}>تعذر تشغيل NOVA CHAT</h2>
            <p>حدث خطأ أثناء تحميل واجهة التطبيق. أرسل صورة هذه الرسالة للدعم.</p>
            <pre style={{
              direction: "ltr", whiteSpace: "pre-wrap", overflowWrap: "anywhere",
              color: "#ffd0d4", fontSize: 12
            }}>{this.state.error.message || String(this.state.error)}</pre>
            <button onClick={() => window.location.reload()} style={{
              padding: "11px 18px", border: 0, borderRadius: 10,
              background: "#5368e8", color: "white"
            }}>إعادة المحاولة</button>
          </section>
        </main>
      );
    }
    return this.props.children;
  }
}

const rootElement = document.getElementById("root");
if (!rootElement) {
  document.body.innerHTML =
    '<main style="padding:24px;background:#0b1020;color:white;min-height:100vh">NOVA CHAT: عنصر تشغيل التطبيق غير موجود.</main>';
} else {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <AppErrorBoundary>
        <App />
      </AppErrorBoundary>
    </React.StrictMode>
  );
}
