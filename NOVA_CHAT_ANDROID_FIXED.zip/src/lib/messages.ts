import { localDb, type LocalMessage } from "./db";
import { supabase } from "./supabase";

export async function savePendingMessage(message: LocalMessage) {
  await localDb.messages.put(message);
}

export async function syncPendingMessages() {
  if (!navigator.onLine || !supabase) return;
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.user?.id) return;
  const pending = await localDb.messages.where("status").equals("pending")
    .sortBy("created_at");

  for (const message of pending) {
    // Never upload messages created by a different or signed-out user.
    if (message.sender_id !== session.user.id) continue;
    const { error } = await supabase.from("messages").upsert({
      id: message.id,
      conversation_id: message.conversation_id,
      sender_id: message.sender_id,
      message_type: "text",
      content: message.content,
      created_at: message.created_at
    }, { onConflict: "id" });

    if (!error) {
      await localDb.messages.update(message.id, { status: "sent" });
    } else {
      console.error("NOVA sync failed:", error.message);
      break;
    }
  }
}
