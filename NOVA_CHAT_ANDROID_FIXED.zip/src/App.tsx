import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Search, Plus, Settings, MessageCircle, Users, Radio, Phone, Sparkles,
  Send, Paperclip, Moon, Sun, Wifi, WifiOff, LogOut, Menu, CheckCheck
} from "lucide-react";
import { supabase, isSupabaseConfigured } from "./lib/supabase";
import { localDb, type LocalMessage } from "./lib/db";
import { savePendingMessage } from "./lib/messages";

type Chat = { id: string; name: string; preview: string; time: string; unread: number; color: string };
const initialChats: Chat[] = [
  { id: "local-friends", name: "الأصدقاء", preview: "أهلًا! عاملين إيه؟", time: "12:45", unread: 2, color: "violet" },
  { id: "local-work", name: "فريق العمل", preview: "تم إرسال الملف", time: "11:20", unread: 0, color: "blue" },
  { id: "local-sara", name: "سارة", preview: "تمام، أشوفك قريبًا", time: "أمس", unread: 0, color: "pink" },
  { id: "local-family", name: "العائلة", preview: "صباح الخير ❤️", time: "أمس", unread: 4, color: "orange" }
];

export default function App() {
  const [chats, setChats] = useState(initialChats);
  const [active, setActive] = useState(initialChats[0]);
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [online, setOnline] = useState(navigator.onLine);
  const [dark, setDark] = useState(true);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("الكل");
  const [userId, setUserId] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [phone, setPhone] = useState("+20");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState("");

  useEffect(() => {
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  useEffect(() => {
    let mounted = true;
    if (!supabase) { setAuthLoading(false); return; }
    supabase.auth.getSession().then(({ data, error }) => {
      if (!mounted) return;
      setUserId(data.session?.user.id ?? null);
      setAuthLoading(false);
      if (error) setAuthError(error.message);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user.id ?? null);
      setAuthLoading(false);
    });
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    let live = true;
    if (!userId) { setMessages([]); return; }
    localDb.messages.where("conversation_id").equals(active.id).sortBy("created_at")
      .then(rows => { if (live) setMessages(rows.filter(row => row.sender_id === userId)); });
    return () => { live = false; };
  }, [active.id, userId]);

  const visibleChats = useMemo(() => chats.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) &&
    (tab !== "غير مقروءة" || c.unread > 0)
  ), [chats, search, tab]);

  async function sendOtp() {
    if (!supabase) {
      setAuthError("إعدادات Supabase غير مكتملة. راجع ملف .env.");
      return;
    }
    const normalizedPhone = phone.trim();
    if (!/^\+[1-9]\d{7,14}$/.test(normalizedPhone)) {
      setAuthError("اكتب رقم الهاتف بالصيغة الدولية، مثل +201xxxxxxxxx.");
      return;
    }
    setAuthBusy(true);
    setAuthError("");
    const { error } = await supabase.auth.signInWithOtp({
      phone: normalizedPhone,
      options: { shouldCreateUser: true }
    });
    if (error) setAuthError(error.message);
    else setOtpSent(true);
    setAuthBusy(false);
  }

  async function verifyOtp() {
    if (!supabase) return;
    const normalizedPhone = phone.trim();
    if (!/^\d{6}$/.test(otp.trim())) {
      setAuthError("كود التحقق لازم يتكوّن من 6 أرقام.");
      return;
    }
    setAuthBusy(true);
    setAuthError("");
    const { error } = await supabase.auth.verifyOtp({
      phone: normalizedPhone,
      token: otp.trim(),
      type: "sms"
    });
    if (error) setAuthError(error.message);
    setAuthBusy(false);
  }

  async function sendMessage() {
    const content = draft.trim();
    if (!content || !userId || !supabase) return;
    const message: LocalMessage = {
      id: crypto.randomUUID(), conversation_id: active.id,
      sender_id: userId, content,
      created_at: new Date().toISOString(), status: "pending"
    };
    await savePendingMessage(message);
    setMessages(prev => [...prev, message]);
    setDraft("");
    setChats(prev => prev.map(c => c.id === active.id
      ? { ...c, preview: content, time: "الآن" } : c));
  }

  async function signOut() {
    await supabase?.auth.signOut();
    setUserId(null);
    setMessages([]);
    setDraft("");
  }

  if (authLoading) {
    return <main className={dark ? "app dark auth-screen" : "app light auth-screen"} dir="rtl"><div className="ambient ambient-one"/><div className="ambient ambient-two"/><div className="auth-modal panel auth-gate"><div className="brand modal-brand"><div className="brand-mark">N</div><div><b>NOVA</b><span>CHAT</span></div></div><h2>جارٍ التحقق من الجلسة</h2><p>لحظة واحدة...</p></div></main>;
  }

  if (!userId) {
    return (
      <main className={dark ? "app dark auth-screen" : "app light auth-screen"} dir="rtl">
        <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
        <header className="topbar"><div className="brand"><div className="brand-mark">N</div><div><b>NOVA</b><span>CHAT</span></div></div><button className="icon-btn" onClick={() => setDark(!dark)} aria-label="تغيير المظهر">{dark ? <Sun/> : <Moon/>}</button></header>
        <section className="auth-gate panel">
          <div className="brand modal-brand"><div className="brand-mark">N</div><div><b>NOVA</b><span>CHAT</span></div></div>
          <h2>{otpSent ? "تأكيد رقم الهاتف" : "مرحبًا بك في NOVA CHAT"}</h2>
          <p>{otpSent ? `أدخل كود التحقق المكوّن من 6 أرقام المرسل إلى ${phone}.` : "سجّل الدخول باستخدام رقم هاتفك. لن تتمكن من فتح المحادثات قبل التحقق."}</p>
          {!isSupabaseConfigured && <div className="config-warning">Supabase غير مُعدّ. أضف VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY في ملف .env.</div>}
          {!otpSent ? (
            <>
              <label className="auth-label">رقم الهاتف بالصيغة الدولية</label>
              <input className="form-input" type="tel" inputMode="tel" autoComplete="tel" placeholder="+201xxxxxxxxx" value={phone} onChange={e => setPhone(e.target.value)} dir="ltr" />
              <button className="primary-wide" disabled={!supabase || authBusy} onClick={() => void sendOtp()}>{authBusy ? "جارٍ إرسال الكود..." : "إرسال كود التحقق"}</button>
            </>
          ) : (
            <>
              <label className="auth-label">كود التحقق</label>
              <input className="form-input otp-input" type="text" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="000000" value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, "").slice(0,6))} dir="ltr" />
              <button className="primary-wide" disabled={!supabase || authBusy || otp.length !== 6} onClick={() => void verifyOtp()}>{authBusy ? "جارٍ التحقق..." : "تأكيد ودخول"}</button>
              <button className="secondary-wide" disabled={authBusy} onClick={() => { setOtpSent(false); setOtp(""); setAuthError(""); }}>تغيير رقم الهاتف</button>
              <button className="text-action" disabled={authBusy} onClick={() => void sendOtp()}>إعادة إرسال الكود</button>
            </>
          )}
          {authError && <div className="auth-error">{authError}</div>}
          <div className="auth-footnote">بالمتابعة، سيتم التحقق من ملكيتك لرقم الهاتف عبر رسالة SMS.</div>
        </section>
      </main>
    );
  }

  return (
    <main className={dark ? "app dark" : "app light"} dir="rtl">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <div className="brand"><div className="brand-mark">N</div><div><b>NOVA</b><span>CHAT</span></div></div>
        <div className="top-actions">
          <div className={`connection ${online ? "online" : "offline"}`}>
            {online ? <Wifi size={15}/> : <WifiOff size={15}/>}
            <span>{online ? "متصل" : "بدون إنترنت"}</span>
          </div>
          <button className="icon-btn" onClick={() => setDark(!dark)} aria-label="تغيير المظهر">{dark ? <Sun/> : <Moon/>}</button>
          <button className="icon-btn" onClick={signOut} aria-label="تسجيل الخروج" title="تسجيل الخروج"><LogOut/></button>
        </div>
      </header>

      <section className="workspace">
        <aside className="sidebar panel">
          <div className="profile-row">
            <div className="avatar self">N<span className="status-dot"/></div>
            <div className="profile-copy"><b>مرحبًا بك في NOVA</b><small>حساب موثّق</small></div>
            <button className="new-chat icon-btn"><Plus size={19}/></button>
          </div>
          <label className="searchbox"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث في المحادثات..." /></label>
          <div className="tabs">{["الكل", "غير مقروءة", "المفضلة"].map(t => <button key={t} className={tab === t ? "selected" : ""} onClick={() => setTab(t)}>{t}</button>)}</div>
          <div className="section-label">المحادثات <span>{visibleChats.length}</span></div>
          <div className="chat-list">
            {visibleChats.map(chat => <button key={chat.id} className={`chat-item ${active.id === chat.id ? "active" : ""}`} onClick={() => setActive(chat)}>
              <div className={`avatar ${chat.color}`}>{chat.name.slice(0,1)}{chat.id === active.id && <i/>}</div>
              <div className="chat-info"><div className="chat-title"><b>{chat.name}</b><time>{chat.time}</time></div><div className="chat-preview"><span>{chat.preview}</span>{chat.unread > 0 && <em>{chat.unread}</em>}</div></div>
            </button>)}
            {visibleChats.length === 0 && <div className="empty-small">لا توجد محادثات مطابقة</div>}
          </div>
          <div className="sidebar-bottom"><span><span className="pulse"/> NOVA CHAT v0.1</span><span>تجربة أولية</span></div>
        </aside>

        <section className="conversation panel">
          <div className="conversation-head">
            <div className="avatar violet">{active.name.slice(0,1)}<i/></div>
            <div className="head-copy"><b>{active.name}</b><small><span className="online-text">●</span> محادثة محلية تجريبية</small></div>
            <div className="head-actions"><button className="icon-btn" title="مكالمة صوتية"><Phone/></button><button className="icon-btn" title="مكالمة فيديو"><Users/></button><button className="icon-btn" title="المزيد"><Menu/></button></div>
          </div>
          <div className="messages-area">
            <div className="date-divider"><span>بداية المحادثة</span></div>
            <div className="welcome-card"><div className="welcome-icon"><Sparkles/></div><b>أهلًا بك في NOVA CHAT</b><p>مساحة تواصل بسيطة. اكتب رسالة لتجربة الحفظ المحلي والعمل دون اتصال.</p></div>
            {messages.map(m => <motion.div initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} key={m.id} className="message-row mine">
              <div className="bubble"><p>{m.content}</p><div className="message-meta"><time>{new Date(m.created_at).toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"})}</time>{m.status === "sent" ? <CheckCheck size={14}/> : <span>{m.status === "pending" ? "قيد الإرسال" : "تعذر الإرسال"}</span>}</div></div>
            </motion.div>)}
          </div>
          <div className="composer-wrap">
            {!online && <div className="offline-note"><WifiOff size={14}/> أنت غير متصل — الرسائل التجريبية ستُحفظ على هذا الجهاز فقط</div>}
            <div className="composer"><button className="attach icon-btn" title="إرفاق ملف"><Paperclip/></button><input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === "Enter") void sendMessage(); }} placeholder="اكتب رسالتك هنا..." /><button className="send-btn" onClick={() => void sendMessage()} aria-label="إرسال"><Send size={18}/></button></div>
            <div className="composer-foot"><span>محادثات تجريبية — الحفظ محلي على هذا الجهاز</span><span>اضغط Enter للإرسال</span></div>
          </div>
        </section>

        <aside className="right-rail">
          <div className="rail-card panel"><div className="rail-icon"><Sparkles/></div><b>NOVA AI</b><p>مساعد ذكي قيد التجهيز. لن تُرسل محادثاتك إلى أي خدمة خارجية في هذه النسخة.</p><button disabled>قريبًا</button></div>
          <div className="rail-card panel"><div className="rail-icon blue-icon"><Users/></div><b>المجموعات</b><p>أنشئ مساحات مشتركة وتواصل مع فريقك.</p><button disabled>قريبًا</button></div>
          <div className="rail-card panel"><div className="rail-icon pink-icon"><Radio/></div><b>القنوات والحالات</b><p>تابع التحديثات وشارك لحظاتك.</p><button disabled>قريبًا</button></div>
          <div className="secure-note"><div>✦</div><span>الخصوصية أولًا</span><small>لا يوجد تشفير طرفي في هذه النسخة. لا تستخدمها لمعلومات حساسة.</small></div>
        </aside>
      </section>

      <footer className="mobile-footer"><button><MessageCircle/>الدردشات</button><button><Users/>المجموعات</button><button><Phone/>المكالمات</button><button><Settings/>الإعدادات</button></footer>
    </main>
  );
}
