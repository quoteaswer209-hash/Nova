import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Vite builds relative asset paths so Capacitor can load them from its local WebView.
export default defineConfig({
  base: "./",
  plugins: [react()],
  build: {
    assetsInlineLimit: 4096,
  },
});
