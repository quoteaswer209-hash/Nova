import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles.css";

function showRuntimeError(title: string, detail: unknown) {
  const root = document.getElementById("root");
  if (!root) return;
  const message = detail instanceof Error
    ? `${detail.name}: ${detail.message}\n${detail.stack ?? ""}`
    : typeof detail === "string" ? detail : JSON.stringify(detail, null, 2);
  root.innerHTML = "";
  const panel = document.createElement("div");
  panel.dir = "rtl";
  panel.style.cssText = "min-height:100dvh;padding:24px;background:#10152b;color:#fff;font:16px sans-serif;white-space:pre-wrap;overflow-wrap:anywhere";
  const heading = document.createElement("h2");
  heading.textContent = "NOVA CHAT — خطأ أثناء التشغيل";
  heading.style.color = "#ff9ca5";
  const explanation = document.createElement("p");
  explanation.textContent = title;
  const pre = document.createElement("pre");
  pre.textContent = message || "لا توجد تفاصيل إضافية";
  pre.style.cssText = "direction:ltr;text-align:left;background:#202943;padding:14px;border-radius:10px;font-size:12px;white-space:pre-wrap;overflow-wrap:anywhere";
  const note = document.createElement("p");
  note.textContent = "صوّر هذه الشاشة وأرسلها لي حتى أحدد سبب المشكلة.";
  panel.append(heading, explanation, pre, note);
  root.append(panel);
}

window.addEventListener("error", (event) => {
  showRuntimeError("حدث خطأ JavaScript أو تعذّر تحميل أحد ملفات التطبيق.", event.error ?? event.message);
});
window.addEventListener("unhandledrejection", (event) => {
  showRuntimeError("حدث خطأ غير معالج أثناء تنفيذ التطبيق.", event.reason);
});

class AppErrorBoundary extends React.Component<{children: React.ReactNode}, {error: Error | null}> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error) { console.error("NOVA React render error:", error); }
  render() {
    if (this.state.error) {
      return <div dir="rtl" style={{minHeight:"100dvh",padding:24,background:"#10152b",color:"#fff",fontFamily:"sans-serif"}}>
        <h2 style={{color:"#ff9ca5"}}>NOVA CHAT — خطأ في عرض الشاشة</h2>
        <pre dir="ltr" style={{whiteSpace:"pre-wrap",overflowWrap:"anywhere",background:"#202943",padding:14,borderRadius:10,fontSize:12}}>{this.state.error.stack || this.state.error.message}</pre>
        <p>صوّر هذه الشاشة وأرسلها لي.</p>
      </div>;
    }
    return this.props.children;
  }
}

const rootElement = document.getElementById("root");
if (!rootElement) {
  document.body.innerHTML = "<p style='color:white;background:#10152b;padding:24px'>NOVA: لم يتم العثور على عنصر root داخل index.html</p>";
} else {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode><AppErrorBoundary><App /></AppErrorBoundary></React.StrictMode>
  );
}
