import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  // Capacitor serves the bundled app from https://localhost/
  base: "/",
  plugins: [react()],
});
