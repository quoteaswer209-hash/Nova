import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Capacitor loads the bundled app from file:// on Android, so assets must use relative paths.
export default defineConfig({
  base: "./",
  plugins: [react()],
});
