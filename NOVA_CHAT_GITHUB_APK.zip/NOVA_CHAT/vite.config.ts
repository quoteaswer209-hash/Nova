import { defineConfig, type Plugin } from "vite";
import type { OutputAsset, OutputChunk } from "rollup";
import react from "@vitejs/plugin-react";

/**
 * Capacitor's Android WebView must not depend on fetching Vite's generated
 * entry bundle from localhost. Inline the complete JS entry and CSS into the
 * packaged index.html so the app can boot even if asset URL resolution fails.
 */
function inlineCapacitorAssets(): Plugin {
  return {
    name: "nova-inline-capacitor-assets",
    apply: "build",
    enforce: "post",
    generateBundle(_options, bundle) {
      const html = bundle["index.html"];
      const entries = Object.values(bundle).filter(
        (item): item is OutputChunk => item.type === "chunk" && item.isEntry,
      );
      const cssAssets = Object.values(bundle).filter(
        (item): item is OutputAsset =>
          item.type === "asset" && item.fileName.endsWith(".css"),
      );

      if (!html || html.type !== "asset" || entries.length !== 1) {
        this.error("NOVA CHAT build must contain index.html and exactly one JavaScript entry.");
      }

      const entry = entries[0];
      if (entry.imports.length > 0 || entry.dynamicImports.length > 0) {
        this.error(
          "JavaScript was split into extra chunks. Keep inlineDynamicImports enabled for the Android build.",
        );
      }

      let htmlText = String(html.source);
      const scriptTag = /<script\b[^>]*\bsrc=["'][^"']+\.js(?:\?[^"']*)?["'][^>]*><\/script>/i;
      if (!scriptTag.test(htmlText)) {
        this.error("Could not find the generated JavaScript entry tag in index.html.");
      }

      const safeJs = entry.code.replace(/<\/script/gi, "<\\/script");
      htmlText = htmlText.replace(
        scriptTag,
        `<script type="module">${safeJs}</script>`,
      );
      delete bundle[entry.fileName];

      for (const css of cssAssets) {
        const cssText = typeof css.source === "string"
          ? css.source
          : new TextDecoder().decode(css.source);
        const safeCss = cssText.replace(/<\/style/gi, "<\\/style");
        let replacedCssLink = false;
        htmlText = htmlText.replace(
          /<link\b[^>]*\bhref=["'][^"']+\.css(?:\?[^"']*)?["'][^>]*>/gi,
          (tag) => {
            if (tag.includes(css.fileName)) {
              replacedCssLink = true;
              return `<style>${safeCss}</style>`;
            }
            return tag;
          },
        );
        if (!replacedCssLink) {
          htmlText = htmlText.replace("</head>", `<style>${safeCss}</style></head>`);
        }
        delete bundle[css.fileName];
      }

      // No generated JS/CSS fetches should remain in the packaged HTML.
      htmlText = htmlText.replace(/<link\b[^>]*rel=["']modulepreload["'][^>]*>/gi, "");
      html.source = htmlText;
    },
  };
}

export default defineConfig({
  base: "./",
  plugins: [react(), inlineCapacitorAssets()],
  build: {
    assetsInlineLimit: 10 * 1024 * 1024,
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
      },
    },
  },
});
